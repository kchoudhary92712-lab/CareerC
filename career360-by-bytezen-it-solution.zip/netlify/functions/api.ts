import { GoogleGenAI, Type } from '@google/genai';
import {
  INITIAL_PLATFORM_DB,
  MASTER_PHASES_SPEC,
  RBAC_PERMISSION_MATRIX,
} from '../../src/data/seedData';
import {
  fromSupabaseBookingRow,
  supabase,
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  SupabaseBookingRow,
  toSupabaseBookingRow,
  toSupabaseLeadRow,
  toSupabaseOrderRow,
} from '../../src/lib/supabase';
import { BookingRecord, OrderRecord } from '../../src/types/platform';

export const handler = async (event: {
  path: string;
  httpMethod: string;
  body?: string | null;
}) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const route = event.path.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '');
  const body = event.body ? JSON.parse(event.body) : {};

  try {
    if (route === '/bootstrap' || route === '/supabase/sync-bookings') {
      const db = structuredClone(INITIAL_PLATFORM_DB);
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (!error && data) {
        const remoteBookings = (data as SupabaseBookingRow[]).map(fromSupabaseBookingRow);
        const map = new Map(db.bookings.map((b) => [b.id, b]));
        for (const rb of remoteBookings) map.set(rb.id, rb);
        db.bookings = Array.from(map.values());
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          db,
          rbac: RBAC_PERMISSION_MATRIX,
          supabaseStatus: {
            projectId: SUPABASE_PROJECT_ID,
            url: SUPABASE_URL,
            tableReady: !error,
            syncedCount: db.bookings.length,
            message: error
              ? error.message
              : `Connected to Supabase (${SUPABASE_PROJECT_ID}). ${db.bookings.length} booking appointments synced.`,
          },
        }),
      };
    }

    if (route === '/bookings' && event.httpMethod === 'POST') {
      const isDirect999 = body.counsellorId === 'direct-desk-999';
      const counsellor =
        INITIAL_PLATFORM_DB.counsellors.find((c) => c.id === body.counsellorId) ||
        INITIAL_PLATFORM_DB.counsellors[0];

      const resolvedCounsellorId = isDirect999 ? 'direct-desk-999' : counsellor.id;
      const resolvedCounsellorName =
        body.counsellorName ||
        (isDirect999
          ? 'Direct Counselling Desk (1-Hr Online · Auto-Assigned)'
          : counsellor.name);
      const resolvedFeeInr = Number(body.feePaidInr ?? (isDirect999 ? 999 : counsellor.feeInr));

      const bookingId = `bk-${Date.now()}`;
      const newBooking: BookingRecord = {
        id: bookingId,
        studentId: body.studentId || 'usr-student-1',
        studentName: body.studentName || 'Student',
        studentCohort: body.studentCohort || 'Class 11-12',
        counsellorId: resolvedCounsellorId,
        counsellorName: resolvedCounsellorName,
        serviceTitle: body.serviceTitle || '1-Hour Online Career Counselling Session',
        date: body.date,
        slot: body.slot,
        mode: body.mode || 'Online Video',
        feePaidInr: resolvedFeeInr,
        status: 'Confirmed',
        meetingLink: `https://meet.bytezenit.com/career360-${bookingId}`,
        notes: body.notes || '',
        createdAt: new Date().toISOString().slice(0, 10),
      };

      const { error } = await supabase
        .from('bookings')
        .upsert(toSupabaseBookingRow(newBooking), { onConflict: 'id' });

      const baseAmount = Math.round(resolvedFeeInr / 1.18);
      const newOrder: OrderRecord = {
        id: `ord-${Date.now()}`,
        userId: newBooking.studentId,
        userName: newBooking.studentName,
        productType: 'Counselling',
        productId: resolvedCounsellorId,
        productName: `${newBooking.serviceTitle} (${resolvedCounsellorName})`,
        amountInr: baseAmount,
        gstInr: resolvedFeeInr - baseAmount,
        discountInr: 0,
        totalPaidInr: resolvedFeeInr,
        paymentMethod: 'UPI',
        invoiceNumber: `BZ-C360-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Paid',
        createdAt: new Date().toISOString().slice(0, 10),
      };

      await supabase
        .from('orders')
        .upsert(toSupabaseOrderRow(newOrder), { onConflict: 'id' })
        .then(() => undefined, () => undefined);

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
          booking: newBooking,
          supabaseSynced: !error,
          supabaseError: error ? error.message : null,
        }),
      };
    }

    if (route === '/leads' && event.httpMethod === 'POST') {
      const newLead = {
        id: `ld-${Date.now()}`,
        name: String(body.name || '').trim(),
        mobile: String(body.mobile || '').trim(),
        email: String(body.email || '').trim(),
        userType: body.userType || 'Student',
        studentClassOrRole: body.studentClassOrRole || 'Class 11-12',
        city: body.city || 'India',
        serviceInterested: body.serviceInterested || 'Career Guidance',
        preferredContact: body.preferredContact || 'WhatsApp',
        leadSource: body.leadSource || 'Website',
        leadOwner: 'Aditi Rao (Senior Career Advisor)',
        leadScore: 88,
        stage: 'New Lead' as const,
        notes: `Interested in ${body.serviceInterested}`,
        followUpDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
        createdAt: new Date().toISOString().slice(0, 10),
      };

      await supabase.from('leads').upsert(toSupabaseLeadRow(newLead), { onConflict: 'id' });
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({ lead: newLead }),
      };
    }

    if (route === '/orders/checkout' && event.httpMethod === 'POST') {
      const gross = Number(body.amountInr) || 999;
      const coupon = String(body.couponCode || '').trim().toUpperCase();
      const rate = coupon === 'FUTURE20' ? 0.2 : coupon === 'BYTEZEN10' ? 0.1 : 0;
      const discountInr = Math.round(gross * rate);
      const totalPaidInr = Math.max(0, gross - discountInr);
      const baseAmount = Math.round(totalPaidInr / 1.18);
      const newOrder = {
        id: `ord-${Date.now()}`,
        userId: body.userId || 'usr-student-1',
        userName: body.userName || 'Student',
        productType: body.productType || 'Report',
        productId: body.productId,
        productName: body.productName,
        amountInr: baseAmount,
        gstInr: totalPaidInr - baseAmount,
        discountInr,
        totalPaidInr,
        paymentMethod: body.paymentMethod || 'UPI',
        couponApplied: rate > 0 ? coupon : undefined,
        invoiceNumber: `BZ-C360-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Paid' as const,
        createdAt: new Date().toISOString().slice(0, 10),
      };

      await supabase.from('orders').upsert(toSupabaseOrderRow(newOrder), { onConflict: 'id' });
      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({ order: newOrder }),
      };
    }

    if (route === '/ai/career-advisor' && event.httpMethod === 'POST') {
      const { cohort = 'Class 11-12', query = '', currentSkills = '' } = body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are the Career360 AI Career Intelligence Advisor by Bytezen IT Solution.
Cohort / Stage: ${cohort}
Current Academic / Skill Background: ${currentSkills}
User Question: ${query}

Provide ethical, structured, non-guaranteed career guidance tailored to the Indian education and industry landscape.`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                executiveSummary: { type: Type.STRING },
                suggestedClusters: { type: Type.ARRAY, items: { type: Type.STRING } },
                recommendedSkillStack: { type: Type.ARRAY, items: { type: Type.STRING } },
                ninetyDayActionPlan: { type: Type.ARRAY, items: { type: Type.STRING } },
                counsellorValidationNote: { type: Type.STRING },
              },
              required: [
                'executiveSummary',
                'suggestedClusters',
                'recommendedSkillStack',
                'ninetyDayActionPlan',
                'counsellorValidationNote',
              ],
            },
          },
        });
        const parsed = JSON.parse(response.text || '{}');
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ advice: parsed }),
        };
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          advice: {
            executiveSummary: `Based on your ${cohort} stage and profile (${currentSkills || 'General Foundation'}), Career360 recommends a structured combination of domain clarity, entrance preparation, and applied future-skills execution.`,
            suggestedClusters: [
              'Technology, Applied AI & Software Systems',
              'Data Analytics, Quantitative Finance & FinTech',
              'Product Strategy, Digital Growth & Management',
            ],
            recommendedSkillStack: [
              'Applied AI & Prompt Engineering Workflows',
              'Analytical Problem Solving & Python / Data Literacy',
              'Executive Communication & Structured Presentation',
            ],
            ninetyDayActionPlan: [
              'Days 1–30: Complete the 14-dimension Career360 diagnostic and shortlist top 2 career clusters.',
              'Days 31–60: Build 1 demonstrable portfolio project and map target college/entrance cutoffs.',
              'Days 61–90: Validate your final roadmap in a 1-hour online session (₹999) with a certified Career360 counsellor.',
            ],
            counsellorValidationNote:
              'Guidance Notice: AI-generated insights represent suggested directions for exploration based on your inputs and are not guaranteed outcomes. Please validate your final roadmap with a certified Career360 counsellor.',
          },
        }),
      };
    }

    if (route === '/mobile/v1/manifest') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          platform: 'Career360 by Bytezen IT Solution',
          apiVersion: 'v1.0.0-mobile-ready',
          supabaseProjectId: SUPABASE_PROJECT_ID,
          phasesCompleted: MASTER_PHASES_SPEC.length,
        }),
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ status: 'ok', route }),
    };
  } catch (err: any) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: err?.message || 'Serverless function error' }),
    };
  }
};

