import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Compass,
  FileText,
  GraduationCap,
  Lock,
  MapPin,
  Menu,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  UserCheck,
  Video,
  X,
} from 'lucide-react';
import { AssessmentEngine } from './components/AssessmentEngine';
import { CareersAndCollegesView } from './components/CareersAndCollegesView';
import { CounsellorsView, SupabaseSyncStatus } from './components/CounsellorsView';
import { EcosystemMatrix } from './components/EcosystemMatrix';
import { RoleWorkspacesView } from './components/RoleWorkspacesView';
import { SkillsAndProView } from './components/SkillsAndProView';
import {
  DIRECT_BOOKING_COHORTS,
  HERO_IMAGE_PATH,
  INDIAN_STATES_LIST,
  INITIAL_PLATFORM_DB,
} from './data/seedData';
import {
  fromSupabaseBookingRow,
  supabase,
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  SupabaseBookingRow,
  toSupabaseBookingRow,
  toSupabaseLeadRow,
  toSupabaseOrderRow,
} from './lib/supabase';
import {
  BookingRecord,
  CohortStage,
  CrmStage,
  EcosystemNodeItem,
  EcosystemPillar,
  LeadRecord,
  OrderRecord,
  PlatformDatabase,
  ReportProduct,
  SkillCourseRecord,
  StudentCareerProfile,
  UserRole,
} from './types/platform';

type ActiveTab = 'ecosystem' | 'assessment' | 'careers' | 'counsellors' | 'skills' | 'workspace';

interface CheckoutTarget {
  productType: 'Report' | 'Skill Course';
  productId: string;
  productName: string;
  priceInr: number;
}

export default function App() {
  const [db, setDb] = useState<PlatformDatabase>(INITIAL_PLATFORM_DB);
  const [activeTab, setActiveTab] = useState<ActiveTab>('ecosystem');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [heroImgFailed, setHeroImgFailed] = useState<boolean>(false);

  // Contextual sub-navigation states when jumping from Ecosystem Matrix
  const [selectedCohort, setSelectedCohort] = useState<CohortStage>('Class 11-12');
  const [careersSubTab, setCareersSubTab] = useState<'careers' | 'compare' | 'colleges' | 'exams'>('careers');
  const [skillsSubCategory, setSkillsSubCategory] = useState<string>('ALL');
  const [workspaceRole, setWorkspaceRole] = useState<UserRole>('Student');

  // Direct Counselling (Rs 999) & State-Wise Counsellor Search states
  const [counsellorSectionMode, setCounsellorSectionMode] = useState<'direct' | 'marketplace'>('direct');
  const [counsellorDirectCohort, setCounsellorDirectCohort] = useState<string>('Class 9-10');
  const [counsellorStateFilter, setCounsellorStateFilter] = useState<string>('ALL');
  const [homeBookingAndStateTab, setHomeBookingAndStateTab] = useState<'direct-booking' | 'state-search'>('direct-booking');
  const [homeSelectedDirectCohort, setHomeSelectedDirectCohort] = useState<string>('Class 9-10');
  const [homeSelectedState, setHomeSelectedState] = useState<string>('Maharashtra');

  // Universal New Customer Basic Details Sign-Up (Required across every part)
  const [customerBasicInfo, setCustomerBasicInfo] = useState<{
    name: string;
    mobile: string;
    email: string;
    state: string;
    category: string;
  } | null>(() => {
    try {
      const saved = localStorage.getItem('career360_customer_basic_signup');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [showQuickSignupModal, setShowQuickSignupModal] = useState<boolean>(false);
  const [pendingNextTab, setPendingNextTab] = useState<ActiveTab | null>(null);
  const [quickName, setQuickName] = useState<string>('');
  const [quickMobile, setQuickMobile] = useState<string>('');
  const [quickEmail, setQuickEmail] = useState<string>('');
  const [quickState, setQuickState] = useState<string>('Maharashtra');
  const [quickCategory, setQuickCategory] = useState<string>('Class 9-10');
  const [quickSignupSavedToast, setQuickSignupSavedToast] = useState<string>('');

  // Phase 2 Authentication & User Account Modal State
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'otp' | 'forgot'>('login');
  const [authRoleType, setAuthRoleType] = useState<'Student' | 'Parent' | 'Working Professional'>('Student');
  const [authName, setAuthName] = useState<string>('Aarav Kulkarni');
  const [authEmailOrMobile, setAuthEmailOrMobile] = useState<string>('+91 98230 11223');
  const [authDob, setAuthDob] = useState<string>('2009-05-14');
  const [authSchoolOrCompany, setAuthSchoolOrCompany] = useState<string>('Symbiosis Junior College, Pune');
  const [authBoardOrIndustry, setAuthBoardOrIndustry] = useState<string>('CBSE · PCM + CS');
  const [authParentOrGoal, setAuthParentOrGoal] = useState<string>('Vikram Kulkarni · AI & Data Engineering');
  const [authStatusMsg, setAuthStatusMsg] = useState<string>('');

  // Lead Capture Form State (Phase 1)
  const [leadName, setLeadName] = useState<string>('');
  const [leadMobile, setLeadMobile] = useState<string>('');
  const [leadEmail, setLeadEmail] = useState<string>('');
  const [leadUserType, setLeadUserType] = useState<
    'Student' | 'Parent' | 'Working Professional' | 'School/College'
  >('Student');
  const [leadClass, setLeadClass] = useState<string>('Class 9-10');
  const [leadCity, setLeadCity] = useState<string>('');
  const [leadService, setLeadService] = useState<string>('Stream Selection & Career Clarity Report');
  const [leadContactMethod, setLeadContactMethod] = useState<'WhatsApp' | 'Phone Call' | 'Email'>('WhatsApp');
  const [leadConsent, setLeadConsent] = useState<boolean>(true);
  const [leadSubmitting, setLeadSubmitting] = useState<boolean>(false);
  const [leadSuccessMsg, setLeadSuccessMsg] = useState<string>('');

  // Checkout Modal State (Phase 5)
  const [checkoutTarget, setCheckoutTarget] = useState<CheckoutTarget | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'Card' | 'NetBanking'>('UPI');
  const [couponCode, setCouponCode] = useState<string>('FUTURE20');
  const [isCheckingOut, setIsCheckingOut] = useState<boolean>(false);
  const [completedOrder, setCompletedOrder] = useState<OrderRecord | null>(null);
  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseSyncStatus | null>(null);

  const syncDirectWithSupabase = async (currentBookings: BookingRecord[]) => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        setSupabaseStatus({
          projectId: SUPABASE_PROJECT_ID,
          url: SUPABASE_URL,
          tableReady: false,
          syncedCount: 0,
          message: error.message,
        });
        return;
      }

      const remoteRows = (data || []) as SupabaseBookingRow[];
      const remoteMap = new Map<string, BookingRecord>();
      for (const r of remoteRows) {
        remoteMap.set(r.id, fromSupabaseBookingRow(r));
      }

      const missingInRemote = currentBookings.filter((b) => !remoteMap.has(b.id));
      if (missingInRemote.length > 0) {
        await supabase
          .from('bookings')
          .upsert(missingInRemote.map(toSupabaseBookingRow), { onConflict: 'id' });
      }

      const combinedMap = new Map<string, BookingRecord>();
      for (const [id, b] of remoteMap.entries()) combinedMap.set(id, b);
      for (const b of currentBookings) {
        if (!combinedMap.has(b.id)) combinedMap.set(b.id, b);
      }

      const mergedBookings = Array.from(combinedMap.values());
      setDb((prev) => ({ ...prev, bookings: mergedBookings }));
      setSupabaseStatus({
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
        tableReady: true,
        syncedCount: mergedBookings.length,
        message: `Connected to Supabase (${SUPABASE_PROJECT_ID}). ${mergedBookings.length} booking appointments synced.`,
      });
    } catch (err: any) {
      setSupabaseStatus({
        projectId: SUPABASE_PROJECT_ID,
        url: SUPABASE_URL,
        tableReady: false,
        syncedCount: 0,
        message: err?.message || 'Unable to reach Supabase endpoint',
      });
    }
  };

  useEffect(() => {
    fetch('/api/bootstrap')
      .then((r) => {
        if (!r.ok) throw new Error('Static deployment mode');
        return r.json();
      })
      .then((data) => {
        if (data?.db) setDb(data.db);
        if (data?.supabaseStatus) setSupabaseStatus(data.supabaseStatus);
      })
      .catch(() => {
        // Direct Supabase sync when hosted on Netlify static CDN
        syncDirectWithSupabase(INITIAL_PLATFORM_DB.bookings);
      });
  }, []);

  const handleSyncSupabase = async () => {
    try {
      const res = await fetch('/api/supabase/sync-bookings', {
        method: 'POST',
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) setDb(data.db);
        if (data?.supabaseStatus) setSupabaseStatus(data.supabaseStatus);
        return;
      }
    } catch {
      // Fall through to direct Supabase sync
    }
    await syncDirectWithSupabase(db.bookings);
  };

  const currentUser = db.users[0] || INITIAL_PLATFORM_DB.users[0];

  const handleSaveCustomerBasicInfo = async (info: {
    name: string;
    mobile: string;
    email: string;
    state: string;
    category: string;
  }) => {
    setCustomerBasicInfo(info);
    try {
      localStorage.setItem('career360_customer_basic_signup', JSON.stringify(info));
    } catch {
      // ignore storage errors
    }

    const signupLead: LeadRecord = {
      id: `ld-signup-${Date.now()}`,
      name: info.name,
      mobile: info.mobile,
      email: info.email || 'customer@bytezenit.com',
      userType:
        info.category === 'Working Professional' || info.category === 'First Job'
          ? 'Working Professional'
          : 'Student',
      studentClassOrRole: info.category,
      city: info.state,
      serviceInterested: `New Customer Sign-Up (${info.category})`,
      preferredContact: 'WhatsApp',
      leadSource: 'Universal Basic Customer Sign-Up',
      leadOwner: 'Aditi Rao (Senior Career Advisor)',
      leadScore: 90,
      stage: 'New Lead',
      notes: `New customer basic sign-up completed from ${info.state} (${info.category}).`,
      followUpDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      createdAt: new Date().toISOString().slice(0, 10),
    };

    await supabase
      .from('leads')
      .upsert(toSupabaseLeadRow(signupLead), { onConflict: 'id' })
      .then(() => undefined, () => undefined);

    setDb((prev) => ({
      ...prev,
      leads: [signupLead, ...prev.leads],
      users: prev.users.map((u, idx) =>
        idx === 0
          ? {
              ...u,
              name: info.name,
              mobile: info.mobile,
              email: info.email || u.email,
              city: info.state,
            }
          : u
      ),
    }));

    setQuickSignupSavedToast(
      `Welcome, ${info.name}! Basic customer sign-up completed for ${info.category} (${info.state}).`
    );
    setTimeout(() => setQuickSignupSavedToast(''), 4000);
  };

  const handleCompleteQuickSignupForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickName.trim() || !quickMobile.trim()) return;
    await handleSaveCustomerBasicInfo({
      name: quickName.trim(),
      mobile: quickMobile.trim(),
      email: quickEmail.trim(),
      state: quickState,
      category: quickCategory,
    });
    setShowQuickSignupModal(false);
    if (pendingNextTab) {
      setActiveTab(pendingNextTab);
      setPendingNextTab(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const navigateWithCustomerCheck = (targetTab: ActiveTab) => {
    setActiveTab(targetTab);
    if (!customerBasicInfo && targetTab !== 'ecosystem') {
      setPendingNextTab(targetTab);
      setShowQuickSignupModal(true);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRedirectStateToCounsellors = (stateName: string) => {
    setCounsellorStateFilter(stateName);
    setCounsellorSectionMode('marketplace');
    setActiveTab('counsellors');
    if (!customerBasicInfo) {
      setQuickState(stateName === 'ALL' ? 'Maharashtra' : stateName);
      setShowQuickSignupModal(true);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRedirectDirectCohortToCounsellors = (cohortId: string) => {
    setCounsellorDirectCohort(cohortId);
    setCounsellorSectionMode('direct');
    setActiveTab('counsellors');
    if (!customerBasicInfo) {
      setQuickCategory(cohortId);
      setShowQuickSignupModal(true);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateNode = (item: EcosystemNodeItem) => {
    if (item.targetTab === 'assessment') {
      if (item.targetSubView) {
        setSelectedCohort(item.targetSubView as CohortStage);
      }
      navigateWithCustomerCheck('assessment');
    } else if (item.targetTab === 'careers') {
      setCareersSubTab(
        item.targetSubView === 'colleges'
          ? 'colleges'
          : item.targetSubView === 'compare'
          ? 'compare'
          : item.targetSubView === 'exams'
          ? 'exams'
          : 'careers'
      );
      navigateWithCustomerCheck('careers');
    } else if (item.targetTab === 'counsellors') {
      navigateWithCustomerCheck('counsellors');
    } else if (item.targetTab === 'skills') {
      setSkillsSubCategory(item.targetSubView || 'ALL');
      navigateWithCustomerCheck('skills');
    } else if (item.targetTab === 'workspace') {
      if (item.targetSubView) {
        setWorkspaceRole(item.targetSubView as UserRole);
      }
      navigateWithCustomerCheck('workspace');
    } else {
      setActiveTab('ecosystem');
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBookCounsellingForNode = (_item: EcosystemNodeItem, _pillar: EcosystemPillar) => {
    navigateWithCustomerCheck('counsellors');
  };

  const handleRequestCallbackForNode = (item: EcosystemNodeItem, pillar: EcosystemPillar) => {
    if (pillar.id === 'for-schools') {
      setLeadUserType('School/College');
      setLeadService('Annual School / College B2B Program');
    } else if (pillar.id === 'parent-services') {
      setLeadUserType('Parent');
      setLeadService('1-on-1 Career Counselling Session');
    } else if (item.id === 'cg-wp' || pillar.id === 'entrepreneurship') {
      setLeadUserType('Working Professional');
      setLeadClass('Working Professional');
      setLeadService('1-on-1 Career Counselling Session');
    } else if (pillar.id === 'skill-development') {
      setLeadUserType('Student');
      setLeadService('Skill Development Course (AI / English / Coding)');
    } else {
      setLeadUserType('Student');
      setLeadService('Stream Selection & Career Clarity Report');
    }
    const deskEl = document.getElementById('consultation-desk');
    if (deskEl) {
      deskEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // API + Direct Supabase Handlers
  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName.trim() || !leadMobile.trim() || !leadEmail.trim()) return;
    setLeadSubmitting(true);
    try {
      const newLead: LeadRecord = {
        id: `ld-${Date.now()}`,
        name: leadName.trim(),
        mobile: leadMobile.trim(),
        email: leadEmail.trim(),
        userType: leadUserType,
        studentClassOrRole: leadClass,
        city: leadCity.trim() || 'Mumbai',
        serviceInterested: leadService,
        preferredContact: leadContactMethod,
        leadSource: 'Homepage Consultation Desk',
        leadOwner:
          leadUserType === 'School/College'
            ? 'K. Choudhary (Institutional Desk)'
            : 'Aditi Rao (Senior Career Advisor)',
        leadScore: leadUserType === 'School/College' ? 95 : 88,
        stage: 'New Lead',
        notes: `Interested in ${leadService}. Preferred contact: ${leadContactMethod}.`,
        followUpDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
        createdAt: new Date().toISOString().slice(0, 10),
      };

      await supabase
        .from('leads')
        .upsert(toSupabaseLeadRow(newLead), { onConflict: 'id' })
        .then(() => undefined, () => undefined);

      try {
        const res = await fetch('/api/leads', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: leadName,
            mobile: leadMobile,
            email: leadEmail,
            userType: leadUserType,
            studentClassOrRole: leadClass,
            city: leadCity || 'Mumbai',
            serviceInterested: leadService,
            preferredContact: leadContactMethod,
            leadSource: 'Homepage Consultation Desk',
            consent: leadConsent,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data?.db) setDb(data.db);
        } else {
          setDb((prev) => ({ ...prev, leads: [newLead, ...prev.leads] }));
        }
      } catch {
        setDb((prev) => ({ ...prev, leads: [newLead, ...prev.leads] }));
      }

      setLeadSuccessMsg(
        `Thank you, ${leadName}! Your enquiry is saved to Supabase and assigned to a Senior Career Advisor via ${leadContactMethod}.`
      );
      setLeadName('');
      setLeadMobile('');
      setLeadEmail('');
      setLeadCity('');
    } finally {
      setLeadSubmitting(false);
    }
  };

  const handleSubmitAssessment = async (payload: {
    userId: string;
    studentName: string;
    cohort: CohortStage;
    academicNotes: string;
    answers: { score: number; clusterTag: string; strengthTag: string }[];
  }): Promise<StudentCareerProfile | null> => {
    try {
      const res = await fetch('/api/assessments/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) setDb(data.db);
        return data?.profile || null;
      }
    } catch {
      // Client-side calculation fallback for static hosting
    }

    const totalScore = payload.answers.reduce((acc, a) => acc + (Number(a.score) || 88), 0);
    const avgScore = Math.min(98, Math.max(75, Math.round(totalScore / Math.max(1, payload.answers.length))));
    const primaryCluster = payload.answers[0]?.clusterTag || 'Technology, AI & Engineering';
    const fallbackProfile: StudentCareerProfile = {
      ...INITIAL_PLATFORM_DB.profiles[0],
      id: `prof-${Date.now()}`,
      userId: payload.userId,
      studentName: payload.studentName,
      cohort: payload.cohort,
      completedAt: new Date().toISOString().slice(0, 10),
      academicSnapshot: `${payload.cohort} · ${payload.academicNotes}`,
      overallReadinessIndex: avgScore,
    };
    setDb((prev) => ({
      ...prev,
      profiles: [fallbackProfile, ...prev.profiles],
    }));
    return fallbackProfile;
  };

  const handleOpenReportCheckout = (rep: ReportProduct) => {
    setCompletedOrder(null);
    setCheckoutTarget({
      productType: 'Report',
      productId: rep.id,
      productName: rep.name,
      priceInr: rep.priceInr,
    });
  };

  const handleOpenCourseCheckout = (course: SkillCourseRecord) => {
    setCompletedOrder(null);
    setCheckoutTarget({
      productType: 'Skill Course',
      productId: course.id,
      productName: course.title,
      priceInr: course.feesInr,
    });
  };

  const handleExecuteCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutTarget) return;
    setIsCheckingOut(true);
    try {
      const normalizedCoupon = couponCode.trim().toUpperCase();
      const discountRate =
        normalizedCoupon === 'FUTURE20' ? 0.2 : normalizedCoupon === 'BYTEZEN10' ? 0.1 : 0;
      const discountInr = Math.round(checkoutTarget.priceInr * discountRate);
      const totalPaidInr = Math.max(0, checkoutTarget.priceInr - discountInr);
      const baseAmount = Math.round(totalPaidInr / 1.18);
      const gstInr = totalPaidInr - baseAmount;

      const fallbackOrder: OrderRecord = {
        id: `ord-${Date.now()}`,
        userId: currentUser.id,
        userName: currentUser.name,
        productType: checkoutTarget.productType,
        productId: checkoutTarget.productId,
        productName: checkoutTarget.productName,
        amountInr: baseAmount,
        gstInr,
        discountInr,
        totalPaidInr,
        paymentMethod,
        couponApplied: discountRate > 0 ? normalizedCoupon : undefined,
        invoiceNumber: `BZ-C360-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        status: 'Paid',
        createdAt: new Date().toISOString().slice(0, 10),
      };

      await supabase
        .from('orders')
        .upsert(toSupabaseOrderRow(fallbackOrder), { onConflict: 'id' })
        .then(() => undefined, () => undefined);

      try {
        const res = await fetch('/api/orders/checkout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUser.id,
            userName: currentUser.name,
            productType: checkoutTarget.productType,
            productId: checkoutTarget.productId,
            productName: checkoutTarget.productName,
            amountInr: checkoutTarget.priceInr,
            paymentMethod,
            couponCode,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          if (data?.db) setDb(data.db);
          if (data?.order) {
            setCompletedOrder(data.order);
            return;
          }
        }
      } catch {
        // Use direct Supabase + client state update
      }

      setDb((prev) => ({
        ...prev,
        orders: [fallbackOrder, ...prev.orders],
        users: prev.users.map((u, idx) =>
          idx === 0
            ? {
                ...u,
                unlockedReportIds:
                  checkoutTarget.productType === 'Report'
                    ? Array.from(new Set([...u.unlockedReportIds, checkoutTarget.productId]))
                    : u.unlockedReportIds,
                enrolledCourseIds:
                  checkoutTarget.productType === 'Skill Course'
                    ? Array.from(new Set([...u.enrolledCourseIds, checkoutTarget.productId]))
                    : u.enrolledCourseIds,
              }
            : u
        ),
      }));
      setCompletedOrder(fallbackOrder);
    } finally {
      setIsCheckingOut(false);
    }
  };

  const handleCreateBooking = async (payload: {
    studentId: string;
    studentName: string;
    studentCohort: string;
    counsellorId: string;
    counsellorName?: string;
    feePaidInr?: number;
    serviceTitle: string;
    date: string;
    slot: string;
    mode: 'Online Video' | 'In-Centre';
    notes: string;
  }): Promise<BookingRecord | null> => {
    const isDirect999 = payload.counsellorId === 'direct-desk-999';
    const counsellor =
      db.counsellors.find((c) => c.id === payload.counsellorId) || db.counsellors[0];
    const bookingId = `bk-${Date.now()}`;
    const directBooking: BookingRecord = {
      id: bookingId,
      studentId: payload.studentId,
      studentName: payload.studentName,
      studentCohort: payload.studentCohort,
      counsellorId: isDirect999 ? 'direct-desk-999' : counsellor.id,
      counsellorName:
        payload.counsellorName ||
        (isDirect999
          ? 'Direct Counselling Desk (1-Hr Online · Auto-Assigned)'
          : counsellor.name),
      serviceTitle: payload.serviceTitle,
      date: payload.date,
      slot: payload.slot,
      mode: payload.mode,
      feePaidInr: payload.feePaidInr ?? (isDirect999 ? 999 : counsellor.feeInr),
      status: 'Confirmed',
      meetingLink: `https://meet.bytezenit.com/career360-${bookingId}`,
      notes: payload.notes,
      createdAt: new Date().toISOString().slice(0, 10),
    };

    // Always write directly to Supabase bookings table first
    await supabase
      .from('bookings')
      .upsert(toSupabaseBookingRow(directBooking), { onConflict: 'id' })
      .then(() => undefined, () => undefined);

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) setDb(data.db);
        return data?.booking || directBooking;
      }
    } catch {
      // Static Netlify fallback
    }

    setDb((prev) => ({
      ...prev,
      bookings: [directBooking, ...prev.bookings],
    }));
    return directBooking;
  };

  const handleToggleSaveCareer = async (careerId: string) => {
    try {
      const res = await fetch('/api/users/save-career', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id, careerId }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) {
          setDb(data.db);
          return;
        }
      }
    } catch {
      // Static fallback
    }
    setDb((prev) => ({
      ...prev,
      users: prev.users.map((u, idx) =>
        idx === 0
          ? {
              ...u,
              savedCareerIds: u.savedCareerIds.includes(careerId)
                ? u.savedCareerIds.filter((id) => id !== careerId)
                : [...u.savedCareerIds, careerId],
            }
          : u
      ),
    }));
  };

  const handleUpdateLeadStage = async (leadId: string, stage: CrmStage) => {
    setDb((prev) => ({
      ...prev,
      leads: prev.leads.map((l) => (l.id === leadId ? { ...l, stage } : l)),
    }));
    try {
      const res = await fetch(`/api/crm/leads/${leadId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) setDb(data.db);
      }
    } catch {
      // Updated in state
    }
  };

  const handleUpdateCounsellorFee = async (counsellorId: string, feeInr: number) => {
    setDb((prev) => ({
      ...prev,
      counsellors: prev.counsellors.map((c) => (c.id === counsellorId ? { ...c, feeInr } : c)),
    }));
    try {
      const res = await fetch(`/api/counsellors/${counsellorId}/availability`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feeInr }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) setDb(data.db);
      }
    } catch {
      // Updated in state
    }
  };

  const handleAddCareerCms = async (payload: {
    name: string;
    category: string;
    description: string;
    eligibility: string;
    entrySalaryInr: string;
  }) => {
    try {
      const res = await fetch('/api/cms/career', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) {
          setDb(data.db);
          return;
        }
      }
    } catch {
      // Static fallback
    }
    setDb((prev) => ({
      ...prev,
      careers: [
        {
          ...prev.careers[0],
          id: `car-${Date.now()}`,
          name: payload.name,
          category: payload.category as any,
          description: payload.description,
          eligibility: payload.eligibility,
          entrySalaryInr: payload.entrySalaryInr,
        },
        ...prev.careers,
      ],
    }));
  };

  const handleRequestSchoolProgram = async (
    schoolName: string,
    city: string,
    mobile: string,
    email: string
  ) => {
    const newSchoolLead: LeadRecord = {
      id: `ld-${Date.now()}`,
      name: `${schoolName} (Institutional B2B)`,
      mobile,
      email,
      userType: 'School/College',
      studentClassOrRole: 'Class 8–12 Institutional Batch',
      city,
      serviceInterested: 'Annual School Career Guidance Program',
      preferredContact: 'Phone Call',
      leadSource: 'B2B School Portal',
      leadOwner: 'K. Choudhary (Institutional Desk)',
      leadScore: 95,
      stage: 'New Lead',
      notes: 'Requested Institutional Partnership Proposal.',
      followUpDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
      createdAt: new Date().toISOString().slice(0, 10),
    };

    await supabase
      .from('leads')
      .upsert(toSupabaseLeadRow(newSchoolLead), { onConflict: 'id' })
      .then(() => undefined, () => undefined);

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: `${schoolName} (Institutional B2B)`,
          mobile,
          email,
          userType: 'School/College',
          studentClassOrRole: 'Class 8–12 Institutional Batch',
          city,
          serviceInterested: 'Annual School Career Guidance Program',
          preferredContact: 'Phone Call',
          leadSource: 'B2B School Portal',
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.db) {
          setDb(data.db);
          return;
        }
      }
    } catch {
      // Static fallback
    }
    setDb((prev) => ({ ...prev, leads: [newSchoolLead, ...prev.leads] }));
  };

  // Discount calculation preview for Checkout Modal
  const discountMultiplier =
    couponCode.trim().toUpperCase() === 'FUTURE20'
      ? 0.2
      : couponCode.trim().toUpperCase() === 'BYTEZEN10'
      ? 0.1
      : 0;
  const checkoutFinalPrice = checkoutTarget
    ? Math.round(checkoutTarget.priceInr * (1 - discountMultiplier))
    : 0;

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-xs border-b border-slate-200">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('ecosystem');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-xl font-bold tracking-tight text-[#0D3B49] font-display whitespace-nowrap"
          >
            Career360
          </a>

          {/* Zone 2: 5 single-line navigation links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
          >
            <button
              type="button"
              onClick={() => setActiveTab('ecosystem')}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                activeTab === 'ecosystem'
                  ? 'text-slate-900 border-[#0F766E] font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Ecosystem
            </button>
            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('assessment')}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                activeTab === 'assessment'
                  ? 'text-slate-900 border-[#0F766E] font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Assessment
            </button>
            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('careers')}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                activeTab === 'careers'
                  ? 'text-slate-900 border-[#0F766E] font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Careers & Colleges
            </button>
            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('counsellors')}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                activeTab === 'counsellors'
                  ? 'text-slate-900 border-[#0F766E] font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Counsellors
            </button>
            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('skills')}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                activeTab === 'skills'
                  ? 'text-slate-900 border-[#0F766E] font-semibold'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Skills & AI
            </button>
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('workspace')}
              className={`px-3.5 py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === 'workspace'
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
              }`}
            >
              Workspaces ({workspaceRole})
            </button>

            <button
              type="button"
              onClick={() => navigateWithCustomerCheck('assessment')}
              className="hidden sm:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-[#0F766E] rounded-lg hover:bg-[#115E59] transition-colors cursor-pointer whitespace-nowrap"
            >
              Take Free Assessment
            </button>

            <button
              type="button"
              aria-label="Toggle Mobile Navigation"
              onClick={() => setMobileMenuOpen((v) => !v)}
              className="md:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-slate-200 px-4 py-4 space-y-2">
            {(
              [
                ['ecosystem', 'Ecosystem & Home'],
                ['assessment', 'Free Career Assessment'],
                ['careers', 'Careers & Colleges'],
                ['counsellors', 'Counsellors Marketplace'],
                ['skills', 'Skill Courses & AI Advisor'],
                ['workspace', 'Role Dashboards & CRM'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => {
                  navigateWithCustomerCheck(key);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold ${
                  activeTab === key
                    ? 'bg-[#F0FDFA] text-[#0F766E]'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* MAIN CONTENT VIEWPORT */}
      <main className="flex-1">
        {/* UNIVERSAL NEW CUSTOMER BASIC DETAILS SIGN-UP BAR (PRESENT ACROSS EVERY PART) */}
        <div className="bg-[#0D3B49] text-white border-b border-slate-800">
          <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-col lg:flex-row lg:items-center justify-between gap-2 text-xs">
            {customerBasicInfo ? (
              <div className="flex flex-wrap items-center justify-between w-full gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-teal-300 shrink-0" />
                  <span className="font-semibold text-teal-200">Active Customer Sign-Up:</span>
                  <span className="font-bold">{customerBasicInfo.name}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{customerBasicInfo.mobile}</span>
                  <span aria-hidden="true">·</span>
                  <span>{customerBasicInfo.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{customerBasicInfo.state}</span>
                </div>
                <div className="flex items-center gap-2">
                  {quickSignupSavedToast && (
                    <span className="text-teal-300 font-semibold">{quickSignupSavedToast}</span>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      setQuickName('');
                      setQuickMobile('');
                      setQuickEmail('');
                      setShowQuickSignupModal(true);
                    }}
                    className="px-3 py-1 rounded bg-white/10 hover:bg-white/20 text-white font-semibold cursor-pointer"
                  >
                    + New Customer Basic Sign-Up
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between w-full gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-300 shrink-0" />
                  <span>
                    <strong>New Customer Quick Sign-Up (Basic Details Only):</strong> Register once with Name, Mobile, State & Category to unlock all platform modules.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowQuickSignupModal(true)}
                  className="px-3.5 py-1.5 rounded-lg bg-[#0F766E] hover:bg-[#115E59] text-white font-bold cursor-pointer whitespace-nowrap self-start sm:self-auto"
                >
                  Complete Basic Sign-Up (10 Secs) →
                </button>
              </div>
            )}
          </div>
        </div>

        {activeTab === 'ecosystem' && (
          <>
            {/* HERO SECTION (PHASE 1) */}
            <section className="py-12 lg:py-16 border-b border-slate-200 bg-white">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                  <div className="lg:col-span-7 space-y-6">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                      <span className="font-semibold text-[#0F766E]">
                        By Bytezen IT Solution (www.bytezenit.com)
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Technology-Enabled Career Guidance & Future-Readiness Platform</span>
                    </div>

                    <h1 className="text-3xl sm:text-5xl font-bold text-slate-900 tracking-tight leading-[1.12]">
                      Discover the Right Career. Build the Right Skills. Prepare for the Future.
                    </h1>

                    <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
                      A complete career intelligence ecosystem connecting{' '}
                      <strong className="text-slate-900 font-semibold">
                        Students, Parents, Working Professionals, Certified Counsellors, Schools & Skill Programs
                      </strong>{' '}
                      from Class 5 through executive leadership.
                    </p>

                    {/* Primary & Secondary Hero CTAs */}
                    <div className="flex flex-wrap items-center gap-3 pt-1">
                      <button
                        type="button"
                        onClick={() => navigateWithCustomerCheck('assessment')}
                        className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[#0F766E] text-white text-sm font-semibold hover:bg-[#115E59] transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <span>Take Free Assessment</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => navigateWithCustomerCheck('counsellors')}
                        className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-[#0D3B49] text-white text-sm font-semibold hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>Book Counselling</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => navigateWithCustomerCheck('careers')}
                        className="inline-flex items-center gap-2 px-5 py-3.5 rounded-lg bg-white border border-slate-300 text-slate-800 text-sm font-semibold hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <Compass className="w-4 h-4 text-[#0F766E]" />
                        <span>Explore Careers</span>
                      </button>
                    </div>

                    {/* Quantitative Proof Strip Adjacent to Hero Proposition */}
                    <div className="pt-6 border-t border-slate-200 grid grid-cols-3 gap-6 max-w-xl">
                      <div>
                        <span className="block text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900">
                          7 Cohorts
                        </span>
                        <span className="text-xs text-slate-500">
                          Class 5–6 to Working Pros
                        </span>
                      </div>
                      <div>
                        <span className="block text-xl sm:text-2xl font-bold font-mono tabular-nums text-[#0F766E]">
                          14 Dimensions
                        </span>
                        <span className="text-xs text-slate-500">
                          Psychometric & Skill Fit
                        </span>
                      </div>
                      <div>
                        <span className="block text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900">
                          100% Validated
                        </span>
                        <span className="text-xs text-slate-500">
                          Human Counsellor + AI Engine
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Hero 16:9 Visual Carrier with Resilient Fallback */}
                  <div className="lg:col-span-5">
                    <div className="relative rounded-2xl overflow-hidden border border-slate-200 bg-[#0D3B49] aspect-video lg:aspect-4/3 shadow-sm">
                      {!heroImgFailed ? (
                        <img
                          src={HERO_IMAGE_PATH}
                          alt="Indian students and career mentor reviewing a structured Career360 roadmap"
                          referrerPolicy="no-referrer"
                          onError={() => setHeroImgFailed(true)}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center text-white bg-gradient-to-br from-[#0D3B49] to-[#0F766E]">
                          <GraduationCap className="w-12 h-12 mb-3 opacity-90" />
                          <p className="text-base font-bold">
                            Career360 Future-Readiness Studio
                          </p>
                          <p className="text-xs text-teal-100 mt-1">
                            Psychometric Assessment · Expert Counselling · Skill Development
                          </p>
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent flex flex-col justify-end p-5 text-white">
                        <p className="text-xs text-teal-200 font-medium">
                          Discovery → Assessment → Profile → Report → Counselling → Skill Execution
                        </p>
                        <p className="text-sm font-semibold mt-0.5">
                          Move beyond guesswork with data-backed career decisions and parent ROI clarity.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 01. INTERACTIVE 6-PILLAR ECOSYSTEM ARCHITECTURE (MATCHING UPLOADED SCREENSHOT) */}
            <EcosystemMatrix
              onNavigateNode={handleNavigateNode}
              onBookCounsellingForNode={handleBookCounsellingForNode}
              onRequestCallbackForNode={handleRequestCallbackForNode}
            />

            {/* 01B. HOME PAGE TAB: DIRECT ₹999 1-HOUR ONLINE BOOKING & STATE-WISE COUNSELLOR SEARCH */}
            <section className="py-14 border-b border-slate-200 bg-white">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-6">
                  <div>
                    <p className="text-xs font-semibold text-[#0F766E] mb-1">
                      Instant Online Counselling Desk & State-Wise Counsellor Finder
                    </p>
                    <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                      Direct 1-Hour Online Booking (₹999) or Search Counsellor State-Wise
                    </h2>
                    <p className="text-sm text-slate-600 mt-1">
                      Book a direct 1-hour online session at flat ₹999 without needing to select a specific counsellor, or search verified counsellors by your Indian State.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 p-1.5 bg-slate-100 rounded-xl border border-slate-200 self-start">
                    <button
                      type="button"
                      onClick={() => setHomeBookingAndStateTab('direct-booking')}
                      className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        homeBookingAndStateTab === 'direct-booking'
                          ? 'bg-[#0D3B49] text-white'
                          : 'text-slate-700 hover:bg-white'
                      }`}
                    >
                      1. Direct 1-Hour Online Booking (₹999 · All 8 Categories)
                    </button>
                    <button
                      type="button"
                      onClick={() => setHomeBookingAndStateTab('state-search')}
                      className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                        homeBookingAndStateTab === 'state-search'
                          ? 'bg-[#0D3B49] text-white'
                          : 'text-slate-700 hover:bg-white'
                      }`}
                    >
                      2. Search Counsellor State-Wise (Redirects to Counsellor Tab)
                    </button>
                  </div>
                </div>

                {homeBookingAndStateTab === 'direct-booking' ? (
                  <div className="p-6 sm:p-8 rounded-2xl bg-[#F8FAFC] border-2 border-[#0F766E] space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                      <div>
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F766E]">
                          <Video className="w-4 h-4" />
                          DIRECT BOOKING WITHOUT RECOMMENDING ANY COUNSELLOR · 1 HOUR ONLINE SESSION
                        </span>
                        <h3 className="text-xl font-bold text-slate-900 mt-1">
                          Select Your Category to Book a 1-Hour Online Session @ Flat ₹999
                        </h3>
                      </div>
                      <span className="px-4 py-2 rounded-xl bg-[#0F766E] text-white font-mono text-base font-bold self-start sm:self-auto">
                        ₹999 / 1 Hour Online
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                      {DIRECT_BOOKING_COHORTS.map((track) => {
                        const isSelected = homeSelectedDirectCohort === track.id;
                        return (
                          <div
                            key={track.id}
                            onClick={() => setHomeSelectedDirectCohort(track.id)}
                            className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                              isSelected
                                ? 'bg-[#0D3B49] text-white border-[#0D3B49] ring-2 ring-[#0F766E]'
                                : 'bg-white text-slate-900 border-slate-200 hover:border-[#0F766E]'
                            }`}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-1.5">
                                <span className="text-sm font-bold">{track.label}</span>
                                <span
                                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                                    isSelected
                                      ? 'bg-[#0F766E] text-white'
                                      : 'bg-teal-50 text-[#0F766E]'
                                  }`}
                                >
                                  ₹999
                                </span>
                              </div>
                              <p
                                className={`text-[11px] font-mono mb-2 ${
                                  isSelected ? 'text-teal-200' : 'text-slate-500'
                                }`}
                              >
                                1 Hour Session Online
                              </p>
                              <p
                                className={`text-xs line-clamp-2 ${
                                  isSelected ? 'text-slate-200' : 'text-slate-600'
                                }`}
                              >
                                {track.focusSummary}
                              </p>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRedirectDirectCohortToCounsellors(track.id);
                              }}
                              className={`mt-4 w-full py-2 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                                isSelected
                                  ? 'bg-[#0F766E] text-white hover:bg-[#115E59]'
                                  : 'bg-slate-900 text-white hover:bg-slate-800'
                              }`}
                            >
                              Book {track.label} @ ₹999 →
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="p-6 sm:p-8 rounded-2xl bg-[#F8FAFC] border-2 border-[#0D3B49] space-y-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                      <div>
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0F766E]">
                          <MapPin className="w-4 h-4" />
                          STATE-WISE COUNSELLOR SEARCH · REDIRECTS DIRECTLY TO COUNSELLOR TAB
                        </span>
                        <h3 className="text-xl font-bold text-slate-900 mt-1">
                          Find Verified Career Counsellors in Your State
                        </h3>
                        <p className="text-xs text-slate-600 mt-0.5">
                          Choose your state below or click any state card to jump straight to the Counsellors tab filtered for your region.
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        <select
                          aria-label="Select State to Search Counsellors"
                          value={homeSelectedState}
                          onChange={(e) => setHomeSelectedState(e.target.value)}
                          className="px-4 py-2.5 text-xs font-semibold bg-white border border-slate-300 rounded-lg"
                        >
                          {INDIAN_STATES_LIST.map((st) => (
                            <option key={st} value={st}>
                              {st}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => handleRedirectStateToCounsellors(homeSelectedState)}
                          className="px-5 py-2.5 rounded-lg bg-[#0F766E] text-white text-xs font-bold hover:bg-[#115E59] cursor-pointer"
                        >
                          Search Counsellors in {homeSelectedState} →
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                      {INDIAN_STATES_LIST.map((stateName) => (
                        <button
                          key={stateName}
                          type="button"
                          onClick={() => handleRedirectStateToCounsellors(stateName)}
                          className="p-3.5 rounded-xl bg-white border border-slate-200 hover:border-[#0F766E] hover:bg-[#F0FDFA] text-left transition-all cursor-pointer flex items-center justify-between gap-2"
                        >
                          <div>
                            <span className="block text-xs font-bold text-slate-900">
                              {stateName}
                            </span>
                            <span className="text-[11px] text-[#0F766E] font-medium">
                              View Counsellors →
                            </span>
                          </div>
                          <MapPin className="w-4 h-4 text-[#0F766E] shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </section>

            {/* 02. WHY CAREER GUIDANCE MATTERS & THE 8-STAGE USER JOURNEY */}
            <section className="py-16 border-b border-slate-200 bg-[#F8FAFC]">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-2xl mb-10">
                  <p className="text-xs font-medium text-[#0F766E] mb-2">
                    02. Structured Career Methodology · Why Career360 Is Not a Coaching Institute
                  </p>
                  <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                    From Career Confusion to Verified Future Readiness
                  </h2>
                  <p className="text-sm text-slate-600 mt-2">
                    Over 68% of students select Class 11 streams or undergraduate degrees based on peer pressure rather than aptitude fit. Career360 replaces anxiety with an 8-step scientific journey:
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {[
                    {
                      step: '01. Free Career Assessment',
                      desc: 'Stage-specific psychometric diagnostic across 14 aptitude, interest, personality, and communication dimensions.',
                      action: 'Start Assessment →',
                      tab: 'assessment' as ActiveTab,
                    },
                    {
                      step: '02. Career Profile & Report',
                      desc: 'Instant Student Career Profile with suggested clusters, 90-day action plan, and downloadable PDF reports.',
                      action: 'View Reports →',
                      tab: 'assessment' as ActiveTab,
                    },
                    {
                      step: '03. 1-on-1 Expert Counselling',
                      desc: 'Human validation with certified psychologists and industry mentors to align student strengths with parent ROI.',
                      action: 'Browse Counsellors →',
                      tab: 'counsellors' as ActiveTab,
                    },
                    {
                      step: '04. Skill & College Execution',
                      desc: 'Close skill gaps in English, AI, Coding, or Finance and shortlist Tier-1 colleges with admission roadmaps.',
                      action: 'Explore Skills & Colleges →',
                      tab: 'skills' as ActiveTab,
                    },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between"
                    >
                      <div>
                        <h3 className="text-base font-bold text-slate-900 mb-2">{item.step}</h3>
                        <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab(item.tab)}
                        className="mt-5 text-xs font-semibold text-[#0F766E] hover:underline text-left cursor-pointer"
                      >
                        {item.action}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* 03. REPORT PRODUCTS & TRANSPARENT PRICING (PHASE 4 & 5) */}
            <section className="py-16 border-b border-slate-200 bg-white">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
                  <div>
                    <p className="text-xs font-medium text-[#0F766E] mb-2">
                      03. Digital Career Report Products · Transparent INR Pricing
                    </p>
                    <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                      Choose the Right Depth of Career Intelligence
                    </h2>
                  </div>
                  <p className="text-xs text-slate-600">
                    Instant dashboard access, GST invoice, and PDF export. Apply code{' '}
                    <span className="font-mono font-bold text-slate-900">FUTURE20</span> for 20% launch savings.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {db.reportProducts.map((rep) => {
                    const isUnlocked =
                      rep.priceInr === 0 || currentUser.unlockedReportIds.includes(rep.id);
                    return (
                      <div
                        key={rep.id}
                        className={`rounded-xl border p-5 flex flex-col justify-between bg-[#F8FAFC] ${
                          rep.id === 'rep-1999'
                            ? 'border-[#0F766E] ring-1 ring-[#0F766E] bg-white'
                            : 'border-slate-200'
                        }`}
                      >
                        <div>
                          <div className="text-xs text-slate-500 mb-1.5">
                            {rep.pageCount} Pages · {rep.recommendedFor.split(' ')[0]}
                          </div>
                          <h3 className="text-base font-bold text-slate-900">{rep.name}</h3>
                          <div className="my-2">
                            <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                              {rep.tierLabel}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 mb-4">{rep.tagline}</p>
                          <ul className="space-y-1.5 text-xs text-slate-700 mb-5">
                            {rep.modulesIncluded.slice(0, 4).map((m, idx) => (
                              <li key={idx} className="flex items-start gap-1.5">
                                <CheckCircle2 className="w-3.5 h-3.5 text-[#0F766E] shrink-0 mt-0.5" />
                                <span>{m}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        {isUnlocked ? (
                          <button
                            type="button"
                            onClick={() => setActiveTab('assessment')}
                            className="w-full py-2.5 px-3 rounded-lg bg-slate-200 text-slate-900 text-xs font-semibold hover:bg-slate-300 cursor-pointer whitespace-nowrap"
                          >
                            View Unlocked Report
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleOpenReportCheckout(rep)}
                            className="w-full py-2.5 px-3 rounded-lg bg-[#0D3B49] text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                          >
                            Unlock Report ({rep.tierLabel})
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* 04. ATTRIBUTABLE SOCIAL PROOF & CASE OUTCOMES */}
            <section className="py-16 border-b border-slate-200 bg-[#F8FAFC]">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="mb-10">
                  <p className="text-xs font-medium text-[#0F766E] mb-2">
                    04. Verified Student, Parent, Professional & Principal Outcomes
                  </p>
                  <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                    Real Decisions Backed by Psychometric & Counsellor Clarity
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
                    <p className="text-xs text-slate-700 leading-relaxed mb-4">
                      “Before Career360, my son was torn between standard JEE coaching and his love for economics and coding. The Career Clarity Report and Dr. Meera’s session helped us target IIIT-H UGEE and SSCBS Delhi with a clear 2-year financial and exam plan.”
                    </p>
                    <div className="pt-4 border-t border-slate-100 text-xs">
                      <p className="font-bold text-slate-900">Vikram & Sunita Kulkarni</p>
                      <p className="text-slate-500">
                        Parents of Class 11 Student · Symbiosis Junior College, Pune
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
                    <p className="text-xs text-slate-700 leading-relaxed mb-4">
                      “After 4 years in manual & automation QA, I used the Working Professional Skill-Gap Analyzer and Applied AI course to build two LLM product workflows. Transitioned into an Associate AI Product Manager role with a 62% compensation jump.”
                    </p>
                    <div className="pt-4 border-t border-slate-100 text-xs">
                      <p className="font-bold text-slate-900">Rohan Deshmukh</p>
                      <p className="text-slate-500">
                        Working Professional (4 YOE) · Enterprise SaaS, Bengaluru
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between">
                    <p className="text-xs text-slate-700 leading-relaxed mb-4">
                      “Deploying the Career360 School Career Dashboard across our Class 9 to 12 batches gave 580+ families objective psychometric profiles and eliminated stream-selection chaos during PTA conclaves.”
                    </p>
                    <div className="pt-4 border-t border-slate-100 text-xs">
                      <p className="font-bold text-slate-900">Dr. S. Radhakrishnan</p>
                      <p className="text-slate-500">
                        Principal · Partner K-12 Institution, Navi Mumbai
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 05. LEAD CAPTURE & EXPERT CONSULTATION DESK + FAQ (PHASE 1 & 18) */}
            <section id="consultation-desk" className="py-16 bg-white">
              <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                  {/* Lead Capture Form */}
                  <div className="lg:col-span-6 bg-[#F8FAFC] rounded-xl border border-slate-200 p-6 sm:p-8">
                    <p className="text-xs font-semibold text-[#0F766E] mb-1">
                      05. Talk to a Career360 Expert · Instant CRM Routing
                    </p>
                    <h2 className="text-xl sm:text-2xl font-bold text-slate-900 mb-2">
                      Request a Callback or Free Career Profile Consultation
                    </h2>
                    <p className="text-xs text-slate-600 mb-6">
                      Whether you are a student, parent, working professional, or school principal, our advisory desk responds within 4 business hours.
                    </p>

                    {leadSuccessMsg && (
                      <div className="mb-6 p-4 rounded-lg bg-[#F0FDFA] border border-[#0F766E] text-xs text-[#0F766E] font-medium">
                        {leadSuccessMsg}
                      </div>
                    )}

                    <form onSubmit={handleLeadSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="lead-name" className="block text-xs font-semibold text-slate-700 mb-1">
                            Full Name *
                          </label>
                          <input
                            id="lead-name"
                            type="text"
                            required
                            placeholder="Enter your full name"
                            value={leadName}
                            onChange={(e) => setLeadName(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label htmlFor="lead-mobile" className="block text-xs font-semibold text-slate-700 mb-1">
                            Mobile Number (WhatsApp) *
                          </label>
                          <input
                            id="lead-mobile"
                            type="tel"
                            required
                            placeholder="+91 98200 00000"
                            value={leadMobile}
                            onChange={(e) => setLeadMobile(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="lead-email" className="block text-xs font-semibold text-slate-700 mb-1">
                            Email Address *
                          </label>
                          <input
                            id="lead-email"
                            type="email"
                            required
                            placeholder="you@example.com"
                            value={leadEmail}
                            onChange={(e) => setLeadEmail(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                        <div>
                          <label htmlFor="lead-city" className="block text-xs font-semibold text-slate-700 mb-1">
                            City / Location *
                          </label>
                          <input
                            id="lead-city"
                            type="text"
                            required
                            placeholder="e.g. Pune, Mumbai, Delhi"
                            value={leadCity}
                            onChange={(e) => setLeadCity(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="lead-usertype" className="block text-xs font-semibold text-slate-700 mb-1">
                            I am a
                          </label>
                          <select
                            id="lead-usertype"
                            value={leadUserType}
                            onChange={(e) =>
                              setLeadUserType(
                                e.target.value as
                                  | 'Student'
                                  | 'Parent'
                                  | 'Working Professional'
                                  | 'School/College'
                              )
                            }
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          >
                            <option value="Student">Student</option>
                            <option value="Parent">Parent</option>
                            <option value="Working Professional">Working Professional</option>
                            <option value="School/College">School / College Principal</option>
                          </select>
                        </div>

                        <div>
                          <label htmlFor="lead-class" className="block text-xs font-semibold text-slate-700 mb-1">
                            Current Class / Stage
                          </label>
                          <select
                            id="lead-class"
                            value={leadClass}
                            onChange={(e) => setLeadClass(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          >
                            <option value="Class 5-6">Class 5–6</option>
                            <option value="Class 7-8">Class 7–8</option>
                            <option value="Class 9-10">Class 9–10 (Stream Selection)</option>
                            <option value="Class 11-12">Class 11–12 (College & Exams)</option>
                            <option value="UG">Undergraduate (UG)</option>
                            <option value="PG">Postgraduate (PG)</option>
                            <option value="Working Professional">Working Professional</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="lead-service" className="block text-xs font-semibold text-slate-700 mb-1">
                            Service Interested In
                          </label>
                          <select
                            id="lead-service"
                            value={leadService}
                            onChange={(e) => setLeadService(e.target.value)}
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          >
                            <option value="Stream Selection & Career Clarity Report">
                              Stream Selection & Career Clarity Report
                            </option>
                            <option value="1-on-1 Career Counselling Session">
                              1-on-1 Career Counselling Session
                            </option>
                            <option value="College Shortlisting & Admission Guidance">
                              College Shortlisting & Admission Guidance
                            </option>
                            <option value="Skill Development Course (AI / English / Coding)">
                              Skill Development Course (AI / English / Coding)
                            </option>
                            <option value="Annual School / College B2B Program">
                              Annual School / College B2B Program
                            </option>
                          </select>
                        </div>

                        <div>
                          <label htmlFor="lead-contact" className="block text-xs font-semibold text-slate-700 mb-1">
                            Preferred Contact Method
                          </label>
                          <select
                            id="lead-contact"
                            value={leadContactMethod}
                            onChange={(e) =>
                              setLeadContactMethod(
                                e.target.value as 'WhatsApp' | 'Phone Call' | 'Email'
                              )
                            }
                            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg"
                          >
                            <option value="WhatsApp">WhatsApp</option>
                            <option value="Phone Call">Phone Call</option>
                            <option value="Email">Email</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 pt-1">
                        <input
                          id="lead-consent"
                          type="checkbox"
                          checked={leadConsent}
                          onChange={(e) => setLeadConsent(e.target.checked)}
                          className="mt-1"
                        />
                        <label htmlFor="lead-consent" className="text-xs text-slate-600">
                          I consent to receive career profile updates, assessment links, and counselling communication from Career360 by Bytezen IT Solution.
                        </label>
                      </div>

                      <button
                        type="submit"
                        disabled={leadSubmitting}
                        className="w-full py-3 px-5 rounded-lg bg-[#0F766E] text-white text-sm font-semibold hover:bg-[#115E59] transition-colors cursor-pointer"
                      >
                        {leadSubmitting ? 'Submitting Enquiry...' : 'Request Free Expert Callback'}
                      </button>
                    </form>
                  </div>

                  {/* Frequently Asked Questions & High-Intent Career Clusters */}
                  <div className="lg:col-span-6 space-y-6">
                    <div>
                      <p className="text-xs font-semibold text-[#0F766E] mb-1">
                        06. Frequently Asked Questions & Parent Clarity
                      </p>
                      <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                        How Career360 Guides Every Career Milestone
                      </h2>
                    </div>

                    <div className="space-y-4">
                      {[
                        {
                          q: 'How is Career360 different from a traditional coaching institute?',
                          a: 'Coaching institutes push every student toward the same exam rat-race. Career360 is a technology-enabled career discovery, psychometric counselling, and skill development partner that identifies where a student naturally excels before recommending streams, exams, or skills.',
                        },
                        {
                          q: 'Are automated assessment results guaranteed career outcomes?',
                          a: 'No. Following strict ethical psychometric standards, our automated reports highlight "Suggested fit" and "Potential pathways" across 14 dimensions. We pair these insights with live 1-on-1 certified counsellors for human validation.',
                        },
                        {
                          q: 'Can parents track their child’s career roadmap and calculate education ROI?',
                          a: 'Yes. The dedicated Parent Dashboard and Career Finance & Education ROI Calculator let families project inflation-adjusted college costs, compare placement payback periods, and review counsellor notes.',
                        },
                        {
                          q: 'How do schools and colleges partner with Career360?',
                          a: 'Through our NEP 2020-aligned School Career Dashboard, institutions run batch psychometric drives for Classes 5–12, host parent stream orientations, and set up an annual on-campus Career Guidance Cell.',
                        },
                      ].map((faq, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-white">
                          <h3 className="text-sm font-bold text-slate-900 mb-1.5">{faq.q}</h3>
                          <p className="text-xs text-slate-600 leading-relaxed">{faq.a}</p>
                        </div>
                      ))}
                    </div>

                    {/* High-Intent SEO Career Pathways Quick Launch */}
                    <div className="p-5 rounded-xl bg-[#F8FAFC] border border-slate-200">
                      <h3 className="text-xs font-bold text-slate-900 mb-2.5">
                        Popular Career Exploration Pathways (Click to Open):
                      </h3>
                      <div className="flex flex-wrap gap-x-3 gap-y-2 text-xs">
                        {[
                          { label: 'Career After 10th (Stream Selection)', cohort: 'Class 9-10' as CohortStage },
                          { label: 'Career After 12th (PCM / PCB / Commerce / Arts)', cohort: 'Class 11-12' as CohortStage },
                          { label: 'AI & Data Science Careers', cohort: 'UG' as CohortStage },
                          { label: 'Working Professional Career Switch', cohort: 'Working Professionals' as CohortStage },
                        ].map((item, i) => (
                          <button
                            key={i}
                            type="button"
                            onClick={() => {
                              setSelectedCohort(item.cohort);
                              setActiveTab('assessment');
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            className="text-[#0F766E] hover:underline font-medium cursor-pointer"
                          >
                            {item.label} →
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}

        {activeTab === 'assessment' && (
          <AssessmentEngine
            initialCohort={selectedCohort}
            currentUser={currentUser}
            profiles={db.profiles}
            reportProducts={db.reportProducts}
            onSubmitAssessment={handleSubmitAssessment}
            onPurchaseReport={handleOpenReportCheckout}
            onBookCounselling={() => setActiveTab('counsellors')}
          />
        )}

        {activeTab === 'careers' && (
          <CareersAndCollegesView
            initialSubTab={careersSubTab}
            careers={db.careers}
            colleges={db.colleges}
            currentUser={currentUser}
            onToggleSaveCareer={handleToggleSaveCareer}
            onBookAdmissionGuidance={() => setActiveTab('counsellors')}
          />
        )}

        {activeTab === 'counsellors' && (
          <CounsellorsView
            counsellors={db.counsellors}
            bookings={db.bookings}
            currentUser={currentUser}
            supabaseStatus={supabaseStatus}
            initialBookingSection={counsellorSectionMode}
            initialDirectCohort={counsellorDirectCohort}
            initialStateFilter={counsellorStateFilter}
            customerBasicInfo={customerBasicInfo}
            onSaveCustomerBasicInfo={handleSaveCustomerBasicInfo}
            onSyncSupabase={handleSyncSupabase}
            onCreateBooking={handleCreateBooking}
          />
        )}

        {activeTab === 'skills' && (
          <SkillsAndProView
            initialCategory={skillsSubCategory}
            courses={db.courses}
            currentUser={currentUser}
            onEnrollCourse={handleOpenCourseCheckout}
            onBookMentor={() => setActiveTab('counsellors')}
          />
        )}

        {activeTab === 'workspace' && (
          <RoleWorkspacesView
            initialRole={workspaceRole}
            db={db}
            onUpdateLeadStage={handleUpdateLeadStage}
            onUpdateCounsellorFee={handleUpdateCounsellorFee}
            onAddCareerCms={handleAddCareerCms}
            onRequestSchoolProgram={handleRequestSchoolProgram}
          />
        )}
      </main>

      {/* CHECKOUT & PAYMENT GATEWAY MODAL (PHASE 5) */}
      {checkoutTarget && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="checkout-modal-title"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full p-6 shadow-xl">
            {completedOrder ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-[#0F766E] font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Payment Verified & Product Unlocked</span>
                </div>
                <h3 id="checkout-modal-title" className="text-lg font-bold text-slate-900">
                  {completedOrder.productName}
                </h3>
                <div className="p-4 rounded-lg bg-[#F8FAFC] border border-slate-200 text-xs space-y-1.5 font-mono">
                  <p>GST Invoice: {completedOrder.invoiceNumber}</p>
                  <p>Base Amount: ₹{completedOrder.amountInr}</p>
                  <p>GST (18%): ₹{completedOrder.gstInr}</p>
                  {completedOrder.discountInr > 0 && (
                    <p className="text-[#0F766E]">
                      Coupon Discount ({completedOrder.couponApplied}): -₹{completedOrder.discountInr}
                    </p>
                  )}
                  <p className="font-bold text-slate-900 text-sm pt-1 border-t border-slate-200">
                    Total Paid: ₹{completedOrder.totalPaidInr} ({completedOrder.paymentMethod})
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCheckoutTarget(null);
                    setCompletedOrder(null);
                  }}
                  className="w-full py-2.5 rounded-lg bg-[#0F766E] text-white text-xs font-semibold hover:bg-[#115E59] cursor-pointer"
                >
                  Access Unlocked Product Now
                </button>
              </div>
            ) : (
              <form onSubmit={handleExecuteCheckout} className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div>
                    <p className="text-xs font-semibold text-[#0F766E]">
                      Phase 5 · Secure Digital Commerce & GST Checkout
                    </p>
                    <h3 id="checkout-modal-title" className="text-base font-bold text-slate-900">
                      {checkoutTarget.productName}
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCheckoutTarget(null)}
                    className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Select Payment Method
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['UPI', 'Card', 'NetBanking'] as const).map((pm) => (
                      <button
                        key={pm}
                        type="button"
                        onClick={() => setPaymentMethod(pm)}
                        className={`py-2 px-3 rounded-lg text-xs font-semibold border cursor-pointer ${
                          paymentMethod === pm
                            ? 'bg-[#0D3B49] text-white border-[#0D3B49]'
                            : 'bg-white text-slate-700 border-slate-300'
                        }`}
                      >
                        {pm}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label htmlFor="checkout-coupon" className="block text-xs font-semibold text-slate-700 mb-1">
                    Coupon Code (Try FUTURE20 or BYTEZEN10)
                  </label>
                  <input
                    id="checkout-coupon"
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono uppercase bg-[#F8FAFC] border border-slate-300 rounded-lg"
                  />
                </div>

                <div className="p-3.5 rounded-lg bg-[#F8FAFC] border border-slate-200 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Standard Fee (incl. GST):</span>
                    <span className="font-mono tabular-nums">₹{checkoutTarget.priceInr}</span>
                  </div>
                  {discountMultiplier > 0 && (
                    <div className="flex justify-between text-[#0F766E] font-medium">
                      <span>Coupon Savings ({Math.round(discountMultiplier * 100)}%):</span>
                      <span className="font-mono tabular-nums">
                        -₹{checkoutTarget.priceInr - checkoutFinalPrice}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-slate-900 text-sm pt-1.5 border-t border-slate-200">
                    <span>Net Payable:</span>
                    <span className="font-mono tabular-nums">₹{checkoutFinalPrice}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isCheckingOut}
                  className="w-full py-3 rounded-lg bg-[#0F766E] text-white text-xs font-semibold hover:bg-[#115E59] cursor-pointer"
                >
                  {isCheckingOut
                    ? 'Verifying Payment...'
                    : `Pay ₹${checkoutFinalPrice} via ${paymentMethod} & Unlock`}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* QUIET INSTITUTIONAL FOOTER */}
      <footer className="bg-[#0F172A] text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-slate-800 text-xs">
            <div className="space-y-2">
              <p className="text-lg font-bold text-white font-display">Career360</p>
              <p className="text-teal-400 font-medium">By Bytezen IT Solution (www.bytezenit.com)</p>
              <p className="text-slate-400 leading-relaxed">
                Technology-enabled Career Guidance, Psychometric Assessment, Counsellor Marketplace & Skill Development Platform.
              </p>
            </div>

            <div>
              <p className="font-bold text-white mb-2.5">Career Guidance Cohorts</p>
              <ul className="space-y-1.5">
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCohort('Class 5-6');
                      setActiveTab('assessment');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    Class 5–6 & Class 7–8 Early Discovery
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCohort('Class 9-10');
                      setActiveTab('assessment');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    Class 9–10 Scientific Stream Selection
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCohort('Class 11-12');
                      setActiveTab('assessment');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    Class 11–12 College & Entrance Roadmap
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCohort('Working Professionals');
                      setActiveTab('assessment');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    UG, PG & Working Professional Pivot
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <p className="font-bold text-white mb-2.5">Platform Modules</p>
              <ul className="space-y-1.5">
                <li>
                  <button
                    type="button"
                    onClick={() => setActiveTab('careers')}
                    className="hover:text-white cursor-pointer"
                  >
                    Central Career Database & A-vs-B Compare
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setCareersSubTab('colleges');
                      setActiveTab('careers');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    College Guidance & Parent ROI Calculator
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setActiveTab('counsellors')}
                    className="hover:text-white cursor-pointer"
                  >
                    Verified Career Counsellor Marketplace
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setActiveTab('skills')}
                    className="hover:text-white cursor-pointer"
                  >
                    Skill Courses & Gemini AI Career Advisor
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <p className="font-bold text-white mb-2.5">Role Portals & Governance</p>
              <ul className="space-y-1.5">
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setWorkspaceRole('Student');
                      setActiveTab('workspace');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    Student & Parent Dashboards
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setWorkspaceRole('Institution Admin');
                      setActiveTab('workspace');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    For Schools & Colleges B2B Dashboard
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setWorkspaceRole('Sales/CRM User');
                      setActiveTab('workspace');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    CRM Pipeline & Lead Automation
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      setWorkspaceRole('Super Admin');
                      setActiveTab('workspace');
                    }}
                    className="hover:text-white cursor-pointer"
                  >
                    Super Admin CMS & RBAC Architecture
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 mb-6">
            <p className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-3">
              Phase 1 Complete 20-Page Public Sitemap & Phase 2 Account Access
            </p>
            <div className="flex flex-wrap gap-2 text-xs">
              {[
                { label: '1. Home', action: () => setActiveTab('ecosystem') },
                { label: '2. About Bytezen', action: () => setActiveTab('ecosystem') },
                { label: '3. Career Guidance', action: () => setActiveTab('ecosystem') },
                { label: '4. Career Assessment', action: () => setActiveTab('assessment') },
                { label: '5. Career Counselling', action: () => setActiveTab('counsellors') },
                { label: '6. Career Options', action: () => { setCareersSubTab('careers'); setActiveTab('careers'); } },
                { label: '7. Student Services', action: () => { setWorkspaceRole('Student'); setActiveTab('workspace'); } },
                { label: '8. Parent Services', action: () => { setWorkspaceRole('Parent'); setActiveTab('workspace'); } },
                { label: '9. Working Professional', action: () => { setSkillsSubCategory('pro-track'); setActiveTab('skills'); } },
                { label: '10. College Guidance & ROI', action: () => { setCareersSubTab('colleges'); setActiveTab('careers'); } },
                { label: '11. Skill Courses', action: () => { setSkillsSubCategory('ALL'); setActiveTab('skills'); } },
                { label: '12. Counsellors', action: () => setActiveTab('counsellors') },
                { label: '13. Schools & Colleges (B2B)', action: () => { setWorkspaceRole('Institution Admin'); setActiveTab('workspace'); } },
                { label: '14. Pricing & Reports', action: () => setActiveTab('assessment') },
                { label: '15. Entrance Exams & Resources', action: () => { setCareersSubTab('exams'); setActiveTab('careers'); } },
                { label: '16. Career Blog', action: () => { setCareersSubTab('exams'); setActiveTab('careers'); } },
                { label: '17. FAQ', action: () => { setActiveTab('ecosystem'); document.getElementById('consultation-desk')?.scrollIntoView({ behavior: 'smooth' }); } },
                { label: '18. Contact Desk', action: () => { setActiveTab('ecosystem'); document.getElementById('consultation-desk')?.scrollIntoView({ behavior: 'smooth' }); } },
                { label: '19. Login (OTP / Google)', action: () => { setAuthMode('login'); setShowAuthModal(true); } },
                { label: '20. Register Account', action: () => { setAuthMode('register'); setShowAuthModal(true); } },
              ].map((pg) => (
                <button
                  key={pg.label}
                  type="button"
                  onClick={pg.action}
                  className="px-2.5 py-1 rounded bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 cursor-pointer"
                >
                  {pg.label}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>© 2026 Career360 by Bytezen IT Solution (www.bytezenit.com). All rights reserved.</p>
            <p>
              Data Privacy & Student Protection Compliant · Ethical Non-Guaranteed Career Advisory
            </p>
          </div>
        </div>
      </footer>

      {/* UNIVERSAL NEW CUSTOMER QUICK SIGN-UP MODAL (BASIC DETAILS ONLY) */}
      {showQuickSignupModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-2xl border-2 border-[#0F766E] max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-2 pb-3 border-b border-slate-200">
              <div>
                <p className="text-xs font-bold text-[#0F766E]">
                  New Customer Sign-Up · Basic Details Only
                </p>
                <h3 className="text-lg font-bold text-slate-900">
                  Quick Customer Registration
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Enter your basic details below to access Assessments, Direct ₹999 Counselling, State-Wise Counsellors, and Courses.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowQuickSignupModal(false)}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCompleteQuickSignupForm} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Enter your full name"
                  value={quickName}
                  onChange={(e) => setQuickName(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-[#F8FAFC] border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Mobile Number (WhatsApp / Call) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98230 00000"
                  value={quickMobile}
                  onChange={(e) => setQuickMobile(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm font-mono bg-[#F8FAFC] border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Email ID (Optional Basic Detail)
                </label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={quickEmail}
                  onChange={(e) => setQuickEmail(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm bg-[#F8FAFC] border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Your State *
                  </label>
                  <select
                    value={quickState}
                    onChange={(e) => setQuickState(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold bg-[#F8FAFC] border border-slate-300 rounded-lg"
                  >
                    {INDIAN_STATES_LIST.map((st) => (
                      <option key={st} value={st}>
                        {st}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Student / Customer Stage *
                  </label>
                  <select
                    value={quickCategory}
                    onChange={(e) => setQuickCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold bg-[#F8FAFC] border border-slate-300 rounded-lg"
                  >
                    {DIRECT_BOOKING_COHORTS.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.label}
                      </option>
                    ))}
                    <option value="Parent">Parent</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-[#0F766E] text-white text-xs font-bold hover:bg-[#115E59] cursor-pointer"
              >
                Save Basic Details & Continue →
              </button>
            </form>
          </div>
        </div>
      )}

      {/* PHASE 2 AUTHENTICATION & USER ACCOUNTS MODAL */}
      {showAuthModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
        >
          <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <p className="text-xs font-semibold text-[#0F766E]">
                  Phase 2 · Secure Authentication & Multi-Role Account System
                </p>
                <h3 className="text-base font-bold text-slate-900">
                  {authMode === 'login'
                    ? 'Sign In via Email, Password or Google'
                    : authMode === 'otp'
                    ? 'Instant Mobile OTP Verification'
                    : authMode === 'forgot'
                    ? 'Account Password Recovery'
                    : `Create ${authRoleType} Account`}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAuthModal(false);
                  setAuthStatusMsg('');
                }}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  ['login', 'Email / Password'],
                  ['otp', 'Mobile OTP'],
                  ['register', 'Register Account'],
                  ['forgot', 'Forgot Password'],
                ] as const
              ).map(([m, label]) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => {
                    setAuthMode(m);
                    setAuthStatusMsg('');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                    authMode === m
                      ? 'bg-[#0D3B49] text-white border-[#0D3B49]'
                      : 'bg-slate-50 text-slate-700 border-slate-200'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {authMode === 'register' && (
              <div className="grid grid-cols-3 gap-2 pt-1">
                {(['Student', 'Parent', 'Working Professional'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setAuthRoleType(r)}
                    className={`py-2 px-2 rounded-lg text-xs font-semibold border cursor-pointer ${
                      authRoleType === r
                        ? 'bg-[#F0FDFA] text-[#0F766E] border-[#0F766E]'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setWorkspaceRole(authRoleType);
                setAuthStatusMsg(
                  `Session verified for ${authName} (${authRoleType}). Workspace permissions and longitudinal profile synced.`
                );
              }}
              className="space-y-3 text-xs"
            >
              {authMode === 'register' && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Full Name ({authRoleType})
                  </label>
                  <input
                    type="text"
                    required
                    value={authName}
                    onChange={(e) => setAuthName(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                  />
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {authMode === 'otp' ? 'Mobile Number (+91)' : 'Email Address or Mobile'}
                </label>
                <input
                  type="text"
                  required
                  value={authEmailOrMobile}
                  onChange={(e) => setAuthEmailOrMobile(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                />
              </div>

              {authMode === 'register' && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        {authRoleType === 'Working Professional'
                          ? 'Years of Experience'
                          : 'Date of Birth'}
                      </label>
                      <input
                        type={authRoleType === 'Working Professional' ? 'text' : 'date'}
                        value={authDob}
                        onChange={(e) => setAuthDob(e.target.value)}
                        className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        {authRoleType === 'Working Professional'
                          ? 'Industry & Job Role'
                          : 'Board & Subjects'}
                      </label>
                      <input
                        type="text"
                        value={authBoardOrIndustry}
                        onChange={(e) => setAuthBoardOrIndustry(e.target.value)}
                        className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      {authRoleType === 'Working Professional'
                        ? 'Current Organization & Education'
                        : 'School / College & City'}
                    </label>
                    <input
                      type="text"
                      value={authSchoolOrCompany}
                      onChange={(e) => setAuthSchoolOrCompany(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">
                      {authRoleType === 'Student'
                        ? 'Parent Details & Career Interests'
                        : authRoleType === 'Parent'
                        ? 'Child Name, Class & School'
                        : 'Skills & Target Career Goals'}
                    </label>
                    <input
                      type="text"
                      value={authParentOrGoal}
                      onChange={(e) => setAuthParentOrGoal(e.target.value)}
                      className="w-full px-3 py-2 bg-[#F8FAFC] border border-slate-300 rounded-lg"
                    />
                  </div>
                </>
              )}

              {authStatusMsg && (
                <p className="p-3 rounded-lg bg-[#F0FDFA] border border-teal-200 text-[#0F766E] font-semibold">
                  {authStatusMsg}
                </p>
              )}

              <div className="flex flex-wrap gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-lg bg-[#0F766E] text-white font-semibold hover:bg-[#115E59] cursor-pointer"
                >
                  {authMode === 'otp'
                    ? 'Verify OTP & Sign In'
                    : authMode === 'forgot'
                    ? 'Send Recovery Link'
                    : authMode === 'register'
                    ? `Complete ${authRoleType} Registration`
                    : 'Sign In to Account'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setAuthStatusMsg(
                      'Google OAuth 2.0 SSO verified. Session token active for ' + authName + '.'
                    );
                  }}
                  className="py-2.5 px-4 rounded-lg bg-white border border-slate-300 text-slate-800 font-semibold hover:bg-slate-50 cursor-pointer"
                >
                  Continue with Google
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
